<?php $__env->startSection('breadcrumbs'); ?>

<ol class="breadcrumb">
	<li class="breadcrumb-item">
	  <a href="index.html">Dashboard</a>
	</li>
	<li class="breadcrumb-item active">Blank Page</li>
</ol>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Page</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>