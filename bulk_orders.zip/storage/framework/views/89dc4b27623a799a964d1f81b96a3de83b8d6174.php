<?php $__env->startSection('content'); ?>

<div class="jumbotron" style="margin: auto; margin-top: 100px; width: 50%; margin-bottom: 300px; background-color: #eee;">

<form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo e(csrf_field()); ?>

  	<h1>Login</h1>
  	<p>Login to your existing account</p>
  	<br>

  	<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
	    <label for="email" >E-Mail Address</label>	    
        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>	    
	</div>

  	<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
	    <label for="password" class="col-md-4 control-label">Password</label>	   
	        <input id="password" type="password" class="form-control" name="password" required>
	        <?php if($errors->has('password')): ?>
	            <span class="help-block">
	                <strong><?php echo e($errors->first('password')); ?></strong>
	            </span>
	        <?php endif; ?>	    
	</div>

  	<div class="form-group">                           
	    <div class="checkbox">
	        <label>
	            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
	        </label>
	    </div>
	</div>

  <div class="form-group">                            
    <button type="submit" class="btn btn-primary">
            Login
    </button>
    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
        Forgot Your Password?
    </a>
    
</div>

</form>
<a  href="/register">Register a new account</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>