<?php $__env->startSection('content'); ?>

<!-- Portfolio Item Row -->
<!-- Page Content -->
    <div class="container">

      <!-- Portfolio Item Heading -->
      <h1 class="my-4"><?php echo e($product->name); ?></h1>

      <!-- Portfolio Item Row -->
      <div class="row">

        <div class="col-md-7">
          <a href="<?php echo e($product->main_image_path); ?>">
            <img class="img-fluid" src="<?php echo e($product->main_image_path); ?>" alt="">
          </a>
        </div>

        <div class="col-md-4">
          <h3 class="my-3">Details</h3>
          <p><?php echo e($product->details); ?></p>
          <p style="font-weight: bold;">Dimensions: <span style="font-weight: normal;"><?php echo e($product->dimensions); ?>  cm</span></p>
          <p style="font-weight: bold;">Thickness: <span style="font-weight: normal;"><?php echo e($product->thickness); ?>  mm</span></p>
          <?php if(!empty($product->weight)): ?>
          <p style="font-weight: bold;">Weight: <span style="font-weight: normal;"><?php echo e($product->weight); ?>  mm</span></p>
          <?php endif; ?>


          <h5 margin-bottom: 1px">Price:  <span style="color: green;">$<?php echo e($product->price); ?></span> / Item</h5>

          <?php if(isset($product->min_quantity)): ?>
            <small style="color: red;">Mininum Order is <?php echo e($product->min_quantity); ?> Pieces</small>
          <?php endif; ?>

          <div style="margin-top: 30px;">
            <?php if(auth()->guard()->check()): ?>
            <form action="/item/<?php echo e($product->id); ?>" method="POST">
              <div class="form-group ">
                <?php echo e(csrf_field()); ?>

                <label for="exampleInputEmail1">Quantity</label>
                <input type="number" name='quantity' class="form-control" id="" aria-describedby="" placeholder="Quantity">
                <input type="hidden" name='product_id' value="<?php echo e($product->id); ?>">
              </div>
              <button type="submit" class="btn btn-success"><i class="fas fa-cart-plus"></i> Add to Cart</button>
            </form>
            <?php else: ?>
            <a href="/login" class="btn btn-success">Add to Cart</a>
            <?php endif; ?>
          </div>

        </div>

      </div>
      <!-- /.row -->

      <!-- Related Projects Row -->
      <?php if(!empty($product->images)): ?>
      <h3 class="my-4">Images</h3>

      <div class="row" style="margin-bottom: 50px">

        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6 mb-4">
          <a href="<?php echo e($image->path); ?>">
            <img class="img-fluid" src="<?php echo e($image->path); ?>" alt="">
          </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>