<?php $__env->startSection('content'); ?>
<section>
<div class="container">
	<?php if(count($carts) > 0): ?>	
	<div class="row">
	
	<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="jumbotron" style="margin-top: 30px">
		  <h1 class="my-4">Order #<?php echo e($cart->id); ?></h1>
		  <h5 class="my-4" style="margin-left: 50%">Status: <span class="badge badge-warning"><?php echo e($cart->status->name); ?></span></h5>
		
		<table class="table table-hover" style="margin: 1px auto; margin-bottom: 1px;">
		  <thead>
		    <tr>
		      
		      <th scope="col">Item Name</th>
		      <th scope="col">Price/Item</th>
		      <th scope="col">Quantity</th>
		      <th scope="col">Total</th>
		      
		    </tr>
		  </thead>
		  <tbody>

		  	<?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
		      
		      <td><?php echo e($item->product->name); ?></td>
		      <td><?php echo e($item->product->price); ?>.00</td>
		      <td><?php echo e($item->quantity); ?></td>
		      <td style="color: darkred"><?php echo e($item->quantity * $item->product->price); ?>.00</td>
		      
		    </tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		  </tbody>
		</table>
		<section style="margin-top: 70px; margin-bottom: 100px;">
		<div class="container">
	  		<div class="row">
	    		<div class="col">
					<div class="card">
					  <h5 class="card-header">Total</h5>
					  <div class="card-body">
					    <h5 class="card-title">Subtotal: <span style="color: darkred">$<?php echo e($cart->total); ?></span></h5>
					    <p class="card-text">Shipping cost is not included.</p>
					  </div>
					</div>
					
				</div>
				<div class="col" style="width: 1000px">
					<div class="card">
					  <h5 class="card-header">Info</h5>
					  <div class="card-body">
					    <h5 class="card-title">Name: </span></h5>
					    <p class="card-text"><?php echo e($cart->name); ?></p>
					    <h5 class="card-title">Company: </span></h5>
					    <p class="card-text"><?php echo e($cart->company); ?></p>
					    <h5 class="card-title">Shipping Address: </span></h5>
					    <p class="card-text"><?php echo e($cart->shipping_address); ?></p>
					    <h5 class="card-title">Email: </span></h5>
					    <p class="card-text"><?php echo e($cart->email); ?></p>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</section>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</div>
	<!-- /.row -->
</div>
</section>



<?php else: ?>
<h2 style="color: grey; margin: 100px auto;">You Have Added any Orders Yet. you can browse our shop here.</h2>
<br>
<a href="/shop" class="btn btn-success" style="margin: 1px auto; margin-bottom: 620px;">Browse Products</a>
<?php endif; ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>